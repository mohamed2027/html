/* ===== Backup reminder strings ===== */
Object.assign(I18N, {
  'bk.lastAt': ['آخر نسخة احتياطية', 'Last backup'],
  'bk.noneYet': ['لم تُؤخذ نسخة بعد', 'No backup taken yet'],
  'bk.due': ['لم تأخذ نسخة احتياطية منذ {n} يوماً. خذ نسخة الآن لحماية بيانات الشركة.', 'No backup for {n} days. Take a backup now to protect this company\'s data.'],
  'bk.dueNever': ['لم تأخذ هذه الشركة نسخة احتياطية بعد. خذ نسخة الآن.', 'This company has no backup yet. Take one now.'],
  'bk.takeNow': ['خذ نسخة الآن', 'Back up now'],
  'bk.later': ['لاحقاً', 'Later'],
  'bk.reminderTitle': ['تذكير بالنسخ الاحتياطي', 'Backup reminder'],
  'bk.everyOn': ['التذكير كل {n} يوماً', 'Reminder every {n} days'],
  'bk.everyOff': ['التذكير بالنسخ متوقف', 'Backup reminder is off'],
  'set.backupEvery': ['تذكير النسخ الاحتياطي كل (أيام، 0 = إيقاف)', 'Backup reminder every (days, 0 = off)'],
});
